package com.mx.development.other;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleJarToWarFileAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleJarToWarFileAppApplication.class, args);
	}

}
