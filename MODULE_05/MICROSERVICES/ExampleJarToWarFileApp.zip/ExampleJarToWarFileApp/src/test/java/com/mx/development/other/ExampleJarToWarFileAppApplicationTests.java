package com.mx.development.other;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleJarToWarFileAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
