package com.mx.templo.ManejoDeExcepciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManejoDeExcepcionesAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManejoDeExcepcionesAppApplication.class, args);
	}

}
