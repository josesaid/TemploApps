package com.codegym.jira.common.util;

import com.codegym.jira.bugtracking.ObjectType;
import com.codegym.jira.bugtracking.tree.NodeTo;
import com.codegym.jira.bugtracking.tree.TreeNode;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;

// TODO
class UtilTest {

    @Test
    void makeTree() {
/*
        NodeTo a = new NodeTo(1L, "A", true, "A", "A", "A", null);
        NodeTo b = new NodeTo(1L, "B", true, "B", "B", "B", a);
        NodeTo c = new NodeTo(1L, "C", true, "C", "C", "C", a);
        NodeTo d = new NodeTo(1L, "D", true, "D", "D", "D", b);
        NodeTo e = new NodeTo(1L, "E", true, "E", "E", "E", d);
        List<NodeTo> projects = List.of(e, b, c, d, a);

        List<TreeNode> nodes = Util.makeTree(projects);
        for (TreeNode treeNode : nodes) {
            System.out.println(treeNode);
        }*/
        List<NodeTo> projects = new ArrayList<>();
        //long id, @NonNull String code, @NonNull ObjectType type, Long parentId
        projects.add(new NodeTo(1L, "abc", ObjectType.PROJECT, 10L));
        assertNotNull(projects);

    }
}