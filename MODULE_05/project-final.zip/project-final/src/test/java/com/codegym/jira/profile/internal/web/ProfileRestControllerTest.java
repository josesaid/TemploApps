package com.codegym.jira.profile.internal.web;

import com.codegym.jira.AbstractControllerTest;


class ProfileRestControllerTest extends AbstractControllerTest {

}