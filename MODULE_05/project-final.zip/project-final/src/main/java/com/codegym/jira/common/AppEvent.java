package com.codegym.jira.common;

// https://spring.io/blog/2015/02/11/better-application-events-in-spring-framework-4-2
public interface AppEvent {
}
