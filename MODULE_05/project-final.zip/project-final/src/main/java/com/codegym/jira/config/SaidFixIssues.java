package com.codegym.jira.config;

import com.codegym.jira.bugtracking.attachment.Attachment;
import com.codegym.jira.bugtracking.attachment.AttachmentMapper;
import com.codegym.jira.bugtracking.attachment.to.AttachmentTo;
import com.codegym.jira.bugtracking.project.Project;
import com.codegym.jira.bugtracking.project.ProjectMapper;
import com.codegym.jira.bugtracking.project.ProjectMapperFull;
import com.codegym.jira.bugtracking.project.to.ProjectTo;
import com.codegym.jira.bugtracking.project.to.ProjectToFull;
import com.codegym.jira.bugtracking.sprint.Sprint;
import com.codegym.jira.bugtracking.sprint.SprintMapper;
import com.codegym.jira.bugtracking.sprint.SprintMapperFull;
import com.codegym.jira.bugtracking.sprint.to.SprintTo;
import com.codegym.jira.bugtracking.sprint.to.SprintToFull;
import com.codegym.jira.bugtracking.task.Activity;
import com.codegym.jira.bugtracking.task.Task;
import com.codegym.jira.bugtracking.task.mapper.ActivityMapper;
import com.codegym.jira.bugtracking.task.mapper.TaskExtMapper;
import com.codegym.jira.bugtracking.task.mapper.TaskFullMapper;
import com.codegym.jira.bugtracking.task.mapper.TaskMapper;
import com.codegym.jira.bugtracking.task.to.ActivityTo;
import com.codegym.jira.bugtracking.task.to.TaskTo;
import com.codegym.jira.bugtracking.task.to.TaskToExt;
import com.codegym.jira.bugtracking.task.to.TaskToFull;
import com.codegym.jira.bugtracking.tree.NodeMapper;
import com.codegym.jira.bugtracking.tree.NodeTo;
import com.codegym.jira.login.User;
import com.codegym.jira.login.UserTo;
import com.codegym.jira.login.internal.UserMapper;
import com.codegym.jira.profile.ContactTo;
import com.codegym.jira.profile.ProfileTo;
import com.codegym.jira.profile.internal.ProfileMapper;
import com.codegym.jira.profile.internal.model.Contact;
import com.codegym.jira.profile.internal.model.Profile;
import com.codegym.jira.profile.internal.web.ProfilePostRequest;
import com.codegym.jira.ref.RefTo;
import com.codegym.jira.ref.internal.Reference;
import com.codegym.jira.ref.internal.ReferenceMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collection;
import java.util.List;

@Configuration
public class SaidFixIssues {

    @Bean
    public ReferenceMapper m13(){
        return new ReferenceMapper() {
            @Override
            public Reference toEntity(RefTo to) {
                return null;
            }

            @Override
            public List<Reference> toEntityList(Collection<RefTo> tos) {
                return List.of();
            }

            @Override
            public Reference updateFromTo(RefTo to, Reference entity) {
                return null;
            }

            @Override
            public RefTo toTo(Reference entity) {
                return null;
            }

            @Override
            public List<RefTo> toToList(Collection<Reference> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public ProfileMapper m12(){
        return new ProfileMapper() {
            @Override
            public ProfileTo toTo(Profile entity) {
                return null;
            }

            @Override
            public Profile updateFromTo(Profile entity, ProfileTo to) {
                return null;
            }

            @Override
            public Contact toContact(ContactTo contact) {
                return null;
            }

            @Override
            public ProfileTo fromPostToTo(ProfilePostRequest profilePostRequest) {
                return null;
            }
        };
    }

    @Bean
    public UserMapper m11(){
        return new UserMapper() {
            @Override
            public User toEntity(UserTo to) {
                return null;
            }

            @Override
            public User updateFromTo(UserTo to, User entity) {
                return null;
            }

            @Override
            public List<User> toEntityList(Collection<UserTo> tos) {
                return List.of();
            }

            @Override
            public UserTo toTo(User entity) {
                return null;
            }

            @Override
            public List<UserTo> toToList(Collection<User> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public NodeMapper m10(){
        return new NodeMapper() {
            @Override
            public NodeTo fromProject(ProjectTo project) {
                return null;
            }

            @Override
            public NodeTo fromSprint(SprintTo sprint) {
                return null;
            }

            @Override
            public NodeTo fromTask(TaskTo task) {
                return null;
            }
        };
    }

    @Bean
    public SprintMapperFull m9(){
        return new SprintMapperFull() {
            @Override
            public Sprint toEntity(SprintToFull to) {
                return null;
            }

            @Override
            public List<Sprint> toEntityList(Collection<SprintToFull> tos) {
                return List.of();
            }

            @Override
            public Sprint updateFromTo(SprintToFull to, Sprint entity) {
                return null;
            }

            @Override
            public SprintToFull toTo(Sprint entity) {
                return null;
            }

            @Override
            public List<SprintToFull> toToList(Collection<Sprint> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public ProjectMapperFull m8(){
        return new ProjectMapperFull() {
            @Override
            public Project toEntity(ProjectToFull to) {
                return null;
            }

            @Override
            public List<Project> toEntityList(Collection<ProjectToFull> tos) {
                return List.of();
            }

            @Override
            public Project updateFromTo(ProjectToFull to, Project entity) {
                return null;
            }

            @Override
            public ProjectToFull toTo(Project entity) {
                return null;
            }

            @Override
            public List<ProjectToFull> toToList(Collection<Project> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public TaskMapper m7(){
        return new TaskMapper() {
            @Override
            public TaskTo toTo(Task task) {
                return null;
            }

            @Override
            public Task toEntity(TaskTo to) {
                return null;
            }

            @Override
            public List<Task> toEntityList(Collection<TaskTo> tos) {
                return List.of();
            }

            @Override
            public Task updateFromTo(TaskTo to, Task entity) {
                return null;
            }

            @Override
            public List<TaskTo> toToList(Collection<Task> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public TaskFullMapper m6(){
        return new TaskFullMapper() {
            @Override
            public TaskToFull toTo(Task task) {
                return null;
            }

            @Override
            public Task toEntity(TaskToFull to) {
                return null;
            }

            @Override
            public List<Task> toEntityList(Collection<TaskToFull> tos) {
                return List.of();
            }

            @Override
            public Task updateFromTo(TaskToFull to, Task entity) {
                return null;
            }

            @Override
            public List<TaskToFull> toToList(Collection<Task> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public TaskExtMapper m5(){
        return new TaskExtMapper() {
            @Override
            public TaskToExt toTo(Task task) {
                return null;
            }

            @Override
            public Task updateFromTo(TaskToExt taskToExt, Task task) {
                return null;
            }

            @Override
            public Task toEntity(TaskToExt to) {
                return null;
            }

            @Override
            public List<Task> toEntityList(Collection<TaskToExt> tos) {
                return List.of();
            }

            @Override
            public List<TaskToExt> toToList(Collection<Task> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public SprintMapper m4(){
        return new SprintMapper() {
            @Override
            public Sprint toEntity(SprintTo to) {
                return null;
            }

            @Override
            public List<Sprint> toEntityList(Collection<SprintTo> tos) {
                return List.of();
            }

            @Override
            public com.codegym.jira.bugtracking.sprint.Sprint updateFromTo(com.codegym.jira.bugtracking.sprint.to.SprintTo to, com.codegym.jira.bugtracking.sprint.Sprint entity) {
                return null;
            }

            @Override
            public SprintTo toTo(Sprint entity) {
                return null;
            }

            @Override
            public List<SprintTo> toToList(Collection<Sprint> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public ProjectMapper m3(){
        return new ProjectMapper() {
            @Override
            public Project toEntity(ProjectTo to) {
                return null;
            }

            @Override
            public List<Project> toEntityList(Collection<ProjectTo> tos) {
                return List.of();
            }

            @Override
            public com.codegym.jira.bugtracking.project.Project updateFromTo(com.codegym.jira.bugtracking.project.to.ProjectTo to, com.codegym.jira.bugtracking.project.Project entity) {
                return null;
            }

            @Override
            public ProjectTo toTo(Project entity) {
                return null;
            }

            @Override
            public List<ProjectTo> toToList(Collection<Project> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public AttachmentMapper m2(){
        return new AttachmentMapper() {
            @Override
            public Attachment toEntity(AttachmentTo to) {
                return null;
            }

            @Override
            public List<Attachment> toEntityList(Collection<AttachmentTo> tos) {
                return List.of();
            }

            @Override
            public com.codegym.jira.bugtracking.attachment.Attachment updateFromTo(com.codegym.jira.bugtracking.attachment.to.AttachmentTo to, com.codegym.jira.bugtracking.attachment.Attachment entity) {
                return null;
            }

            @Override
            public AttachmentTo toTo(Attachment entity) {
                return null;
            }

            @Override
            public List<AttachmentTo> toToList(Collection<Attachment> entities) {
                return List.of();
            }
        };
    }

    @Bean
    public ActivityMapper m1(){
        return new ActivityMapper() {
            @Override
            public Activity updateFromTo(ActivityTo activityTo, Activity activity) {
                return null;
            }

            @Override
            public Activity toEntity(ActivityTo to) {
                return null;
            }

            @Override
            public List<Activity> toEntityList(Collection<ActivityTo> tos) {
                return List.of();
            }

            @Override
            public ActivityTo toTo(Activity entity) {
                return null;
            }

            @Override
            public List<ActivityTo> toToList(Collection<Activity> entities) {
                return List.of();
            }
        };
    }

}
