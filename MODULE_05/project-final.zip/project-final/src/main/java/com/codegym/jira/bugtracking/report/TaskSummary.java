package com.codegym.jira.bugtracking.report;

public record TaskSummary(String status, long total) {
}
